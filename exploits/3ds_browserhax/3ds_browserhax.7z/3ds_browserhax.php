<?php

$appendstr = "";
if(isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] !== "")$appendstr = "?" . $_SERVER['QUERY_STRING'];

$ua = $_SERVER['HTTP_USER_AGENT'];
if(!strstr($ua, "Mozilla/5.0 (Nintendo 3DS; U; ; ") && !strstr($ua, "Mozilla/5.0 (New Nintendo 3DS"))
{
	echo "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /></head>This page is only intended for the system web-browsers for Nintendo 3DS, since you're using a non-3DS browser go <a href=\"/exploits/3ds_browserhax/\">here</a>.";
	exit;
}

$page = "";

if(strstr($ua, "Mozilla/5.0 (Nintendo 3DS; U; ; "))
{
	if(strstr($ua, "1.7538") || strstr($ua, "1.7616"))
	{
		$page = "spider28hax.php";
	}
	else
	{
		$page = "spider31hax.php";
	}

	header("Location: http://".$_SERVER['SERVER_NAME']."/exploits/3ds_browserhax/$page$appendstr");
}
else if(strstr($ua, "Mozilla/5.0 (New Nintendo 3DS"))
{
	if(strstr($ua, "1.0.9934") || strstr($ua, "1.1.9996") || strstr($ua, "1.2.10085") || strstr($ua, "1.3.10126"))
	{
		$page = "browserhax_fright.php";
	}
	else if(strstr($ua, "1.4.10138") || strstr($ua, "1.5.10143"))
	{
		$page = "browserhax_fright_tx3g.php";
	}
	else
	{
		$page = "skater31hax.php";
	}

	echo "<html><head><script>window.location.assign(\"http://".$_SERVER['SERVER_NAME']."/exploits/3ds_browserhax/$page$appendstr\");</script></head><body></body></html>";
}

exit;

?>